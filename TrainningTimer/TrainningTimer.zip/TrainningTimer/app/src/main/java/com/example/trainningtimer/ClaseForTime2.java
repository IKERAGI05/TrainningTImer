package com.example.trainningtimer;

import android.app.Activity;
import android.os.Bundle;

public class ClaseForTime2 extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_fortime2);


    }


}
