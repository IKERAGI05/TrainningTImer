package com.example.trainningtimer;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ClaseForTime extends Activity {

    private Spinner spinnerFT;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_fortime);
        spinnerFT=findViewById(R.id.spinner_ft);
        //Array con el que se carga el Spinner
        String[] spinnerContent= new String[100];
        spinnerContent[0]="Indef";
        int y=3;
    try {
        //El for que rellena el Spinner
        for (int x = 1; x < 99; x++) {

                spinnerContent[x] = y + "min";

                y++;



        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, spinnerContent);
        spinnerFT.setAdapter(adapter);

    }catch (Exception e){
        Toast toast = null;

        toast.makeText(getApplicationContext(), "Fuera del pointer", Toast.LENGTH_SHORT);

    }




    }

    public void comenzarTimer(View view){

        Intent intent=new Intent(this, ClaseForTime2.class);
        startActivity(intent);


    }
}